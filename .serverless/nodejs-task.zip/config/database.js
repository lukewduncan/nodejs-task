module.exports = {
  'secret': 'fdd613242af69deb334a93078b4f71d9',
  'database': 'mongodb+srv://luke:luke@cluster0-lc8dq.mongodb.net/test?retryWrites=true&w=majority',
  'test_database': 'mongodb+srv://luke:luke@cluster0-kduld.mongodb.net/test?retryWrites=true&w=majority'
};